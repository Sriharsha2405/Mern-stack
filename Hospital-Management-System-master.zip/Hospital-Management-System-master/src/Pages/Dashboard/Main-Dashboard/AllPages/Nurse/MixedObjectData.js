export const CommonProblem = [
  {
    title: "Fever",
    value: "Fever",
  },
  {
    title: "Headaches",
    value: "Headaches",
  },
  {
    title: "Allergies",
    value: "Allergies",
  },
  {
    title: "Cold and Flu",
    value: "Cold and Flu",
  },
  {
    title: "Diarrhea",
    value: "Diarrhea",
  },
  {
    title: "Stomach Aches",
    value: "Stomach Aches",
  },
  {
    title: "Other Problem",
    value: "Other Problem",
  },
];

export const DepartmentData = [
  {
    title: "Psychiatrist",
    value: "Psychiatrist",
  },
  {
    title: "Pediatrics",
    value: "Pediatrics",
  },
  {
    title: "Dermatology",
    value: "Dermatology",
  },
  {
    title: "Pediatrician",
    value: "Pediatrician",
  },
  {
    title: "Neurologist",
    value: "Neurologist",
  },
];

export const Psychiatrist = [
  {
    title: "Dr.Rajendra Patel",
    value: "Dr.Rajendra Patel",
  },
  {
    title: "Dr.Rajendra Patel",
    value: "Dr.Rajendra Patel",
  },
  {
    title: "Dr.Rajendra Patel",
    value: "Dr.Rajendra Patel",
  },
];

export const Pediatrics = [
  {
    title: "Dr.Piyush Agarwal",
    value: "Dr.Piyush Agarwal",
  },
  {
    title: "Dr.Piyush Agarwal",
    value: "Dr.Piyush Agarwal",
  },
  {
    title: "Dr.Piyush Agarwal",
    value: "Dr.Piyush Agarwal",
  },
];

export const Dermatology = [
  {
    title: "Dr.Udhaya",
    value: "Dr.Udhaya",
  },
  {
    title: "Dr.Udhaya",
    value: "Dr.Udhaya",
  },
  {
    title: "Dr.Udhaya",
    value: "Dr.Udhaya",
  },
];

export const Pediatrician = [
  {
    title: "Dr.Masai",
    value: "Dr.Masai",
  },
  {
    title: "Dr.Masai",
    value: "Dr.Masai",
  },
  {
    title: "Dr.Masai",
    value: "Dr.Masai",
  },
];

export const Neurologist = [
  {
    title: "Dr.Elon Musk",
    value: "Dr.Elon Musk",
  },
  {
    title: "Dr.Elon Musk",
    value: "Dr.Elon Musk",
  },
  {
    title: "Dr.Elon Musk",
    value: "Dr.Elon Musk",
  },
];
